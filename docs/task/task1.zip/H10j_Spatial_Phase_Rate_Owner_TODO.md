# H10j / 同源空间相通量 prepared owner

状态：**等待H10i1b–f实际来源消费链实现及H10i空间设计复核，不是当前下一任务**。[H10i1a Core port](H10i1a_Native_Quartic_Trace_Port_Report.md)已PASS，1,408真实段/40零迹/80侧区间通过；真实质量/clip/native出版消费者尚未迁移。下一唯一任务[H10i1b闭合裁剪矩](H10i1b_Closed_Clip_Moments_TODO.md)。本文件仅登记有条件的空间factory范围，尚未实施；Core来源PASS不能当作新材料通量或完整来源消费链PASS。H10/H11/H08a顺序保持。

目标：在 Hydro 侧用同一 FirstJet 和实际 compatible advector，准备 primal/dual 的同源空间相通量视图，使后续唯一 F_rho owner 可直接消费真实相区间，不再以材料散度/面积分配代替材料积分。只实现这一个事实。

允许修改：`include/Modules/Hydrodynamics/CchPhaseGeometry.h`、`src/Modules/Hydrodynamics/CchPhaseGeometry.cpp`（2 production）；现 `tests/contracts/hydrodynamics/cch_phase_geometry_contract.cpp`（1 test）；既有 `cases/benchmarks/cch_convection/driver.cpp`/README 和对应设计/API/报告。使用原 CMake owner 与标准 target，不新增工具或变体文件。临时目录 `runs/checks/H10j/<时间戳>`，关闭证据归 baselines。

禁止修改：Interface primary/出版/Q4、库存/bubble/质量修复、D_I/C、黏性/电场、材料密度定义、旧 H08/H09 F/R/uR、旧 App/字典/PDF、原 H10b gate。无独立高阶全局状态、AMR 特例、解析输入修正、界面重构或隐式 fallback。本阶段不把新 phase-rate 拿去替代未迁移的 material owner。

数学约束：材料耦合硬约束仅唯一共享 F_rho、内部面反号共享/真实 AMR 子面求和、来源一致、KEP/skew；本阶段提供它们需要的同源 phase-rate 和 advector 数据，不要求材料 commuting/quarter/R=0。按 H10i 构造运动学 trace/lift，在真实面积上保存 `Q=A*u` 及 `div B=(D_I*u)/V`。这些是候选运动学构造，不重新强制 pressure 材料散度分配给 dual。

实现要求：

- 现 CchPhaseRate 增加 `prepareSpatial(mesh, phase, momentumGeometry, actualValues, geometryIdentity, fullClock)`，immutable 数据保留 actual advector、同一几何/布局/D_I、显式 geometry instance 与完整来源。新增只读 `momentumGeometry/dualFaceRates/spatialReport/advectorIdentity` 等必要 port；不裸露 mutable cache、phase rate数组 setter或 snapshot shared_ptr。
- 原 evaluate 暂为当前消费者的历史面常值入口；新 factory 不调用旧材料延拓，也不在失败后转入 evaluate。下一 H10k 完成入口迁移并删除旧空间算法；本任务不声称 production 路线已替换。禁止将新 factory 的 API PASS 冒称 H08/H09 或 H10 PASS。
- 每个真实 native face 的一般 one-ring 三列 physical-mean functional，统一 scaled SVD 最小范数；面内一次 trace 的 mean 精确还原 u_f。RZ s=r²/2、径向 u_r/r 仅在正半径使用，轴0正规。未识别切向 functional 保存显式缺口，不引入另一算法，也不要求整个 rank deficient patch 精确二维 affine。
- 实际 cell 的 transfinite 延拓加 H10i 的显式 zero-normal divergence lift；分片按真实子面，RZ 运用 `(r*u_r,u_z)` 在 `(s,z)` 上的公式。保留相同 primal normal trace；不是材料 quarter 最小改动求解。
- primal/两个 velocity component 的真实 dual segment 做 canonical atom overlay，独立正向段只查询一次，视图用有向索引聚合；同源 `LevelSetMappedSegment` 的 endpoint-relative ranges 积分 phase trace。使用 owning geometry view alias，不复制 scalar或穿透 Detail，不重建两个全局 root端点后相减；无法用全局浮点内部点时使用 shifted chart polynomial。
- 正物理相权重，sign 来自 actual velocity。候选 trace 的三点 Gauss精度范围按 H10i；细相不可丢弃/clip/吸收，轴零面积率严格0。非有限/分解/几何query失败明确拒绝。
- `CchAdvectorIdentity` 不可由调用者任意构造，新的实际 prepared revision有新 identity；下游 H10k 增加对应 CchMaterialSources字段检查。本阶段不制造接受状态或主时钟。
- native actual advector point 查询来自同一 prepared B，normal从shared trace，transverse按真实相邻cell几何交集权重；不按密度权重，不用另一个研究恢复器或解析解。来源只表示输入声明和 immutable owner，不冒称已实施 H14。
- 几何矩阵/拓扑只准备一次，当前速度更新只改变派生系数；局部数据规模/耗时随真实 native面/段线性，禁止持续膨胀全局高阶DOF。

验收：T0 标准 Release、architecture/self-test/repository layout、原 App/输入/PDF哈希保持。T1 新 spatial factory 来源拒绝、同面反号/AMR atomic求和/physical closure、原 D_I total恢复和 volume-coordinate divergence均≤1e−12 gross；所有原时间/identity/轴/正负与零速度/小相/regrid拒绝场景保留。

16 full布局（XY/RZ uniform/2:1 n4/8/16/32）及原三类 selected：分别记录识别/不识别 tangent functional。H10i实测38,770面中72 rank deficient、56 tangent未识别（仅n4 selected2/3），不得把这56行从共享/有限/来源检查删掉，也不得把它们标成二维affine精确。full16和n≥8 selected必须再现可识别的affine，≤1e−12；极粗信息不足者按同一个最小范数构造验代数自洽并明确精度限制。

独立解析测试必须区分面平均与点样本：XY全affine、RZ `u_r=a*r,u_z=b+c*z`及可识别轴向even-r² physical-average family；带真实斜切/曲面/小相时，phase polynomial积分与独立closed-form或shifted moment核验≤1e−12相尺度。不得用新kernel自身做参考；RZ point/mean差异按O(h²)报告，原H10b点参考不改。

真实Pure FirstJet三层移动/crossing/regrid来源、H10h pure gas dof103全部三层21边段、正物理XY/RZ相测度、同物理段与父/子段moment加回、prepared复制和source寿命验证；测试新 spatial实际输出，无密度库存或材料时间update。原 phase/material/dual/KEP回归全部记录。本任务前置失败时不重跑完整H10b；不进入H11/H08a。

失败规则：任何空间构造/可识别矩/真实source/共享/细相/正规性或必要回归失败均FAIL；冻结诊断并修正或拆接口任务，无旧evaluate fallback。极粗selected不可识别是已预先列出的精度限制，不能在试验后借此豁免full/n≥8精度。只有真实外部依赖才BLOCKED。

交付：实现/API、实际new factory短契约/源段研究结果、所有不支持或未验证项、明确候选/旧consumer状态、平面manifest及protected核验；下一H10k单独迁移phase/material入口。H10k后H10l迁移唯一dual F/R/E_sp，再独立收口最终native PDE和原H10b，不能仅以材料输入改善关闭H10。

补充正式零迹契约：[H10i1设计](H10i1_Coincident_Phase_Trace_Clip_Contract_Design.md)。新factory只用同一typed NativeQuarticTrace的两侧迹与实际advector，按a正负分片取因果流入相；clip内部迹、无速度对称诊断测度均不得代替材料率。外部/selected零迹流入无正式相数据须拒绝，axis率严格0。完成后验原16重合场景、正负零速度及变号、normal反向/子面求和、wrong source与生命周期，并用独立平移右时间导数核验；不得恢复half分配、R=0或库存。H10i1f已迁移H07 trace kind与legacy拒绝，H10j预算只实施spatial owner，不隐含Core/Interface修改。

H10i1a正式Core NativeQuarticTrace已验收（1,408段/40零迹/80侧范围）；本空间工厂仍等待H10i1b–f真实clip/volume/publication链。Core point-only value incidence仅保留endpoint来源，不是一条正长度零曲线；ordinary与side事件不能从rounded global参数合并。
