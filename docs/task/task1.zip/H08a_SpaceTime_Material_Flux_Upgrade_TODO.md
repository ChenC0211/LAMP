# H08a / 同源时空相积分材料通量（待启动）

状态：待启动，2026-10-04用户授权顺序：H10最终native空间离散通过后开始。[H10i1a Core只读相迹](H10i1a_Native_Quartic_Trace_Port_Report.md)已PASS：正式同源zero/两侧normal Taylor port完成，真实1,408段/40零迹/80侧区间核验通过。真实质量/clip/native出版消费者仍拒绝，材料与最终convection未迁移。下一唯一任务[H10i1b闭合裁剪矩](H10i1b_Closed_Clip_Moments_TODO.md)，随后逐项完成H10i1c–f，再复核H10i并实施H10j空间owner。用户四材料硬约束保持，本时空积分任务尚未启动。

目标：保持Pure FirstJet/Hermite–GALS几何完全独立，在Hydro侧从同一实际步内几何和特征运动积分共享face的液/气相输运，构造唯一材料通量F_rho，使材料连续性缺陷R成为可收敛的小离散余项。

允许修改：启动时先审计H07/H08/H09的来源、完整clock及共享子面API，再另行固定实现文件清单和不超过5 production / 2 test的预算；本轮只有文档登记，无H08源码修改。

禁止修改：Interface primary、几何发布/曲率、库存、bubble、逐cell体积拟合、材料修复或另一套rho*u通量。不以积分通量更新一个守恒质量状态；真实材料质量仍直接来自唯一GALS几何。

数学约束：液气相积分共享同一时空几何，材料积分为rho_l*Q_l+rho_g*Q_g；内部共享face和2:1真实subfaces保持唯一来源与代数抵消。逐cell和dual的R必须从真实几何质量变化及该唯一积分重新核算，不能设为0。继续现有uR、|u|²R/2及KEP相容对流，不反向约束界面。

实现要求：先定义同源步内几何/characteristic来源、积分精度预算、时间层和拒绝条件。仅三个独立snapshot做插值或midpoint面积乘dt不能自动称为同源时空相积分；不得重新启用历史守恒Interface driver作为生产owner。

验收：启动前在实现前设计中固定T0/T1/T2数值门槛及完整研究窗口。至少包括真实moving/crossing相面、XY/RZ uniform/2:1、共享face求和、光滑与穿越情况下R的空间/时间收敛、密度比1/1e3/1e6、既有常速度/uR/KE预算、真实regrid来源重建及全部前置回归。不得以严格R=0为目标，不能在结果出来后改阈值。

失败规则：不同源、第二材料通量、不可收敛或来源拒绝失败判FAIL；无旧midpoint或守恒库存fallback。真正外部依赖阻断才BLOCKED。

交付：唯一积分API/实现、R及材料功的独立完整证据、明确误差和剩余缺陷。H08历史报告保持原裁决，不把旧中点研究改标为时空积分。

## H08/H09 解除过约束（2026-10-04 用户授权）

材料耦合硬约束仅四项：唯一共享材料通量、内部面反号共享/AMR 子面守恒、来源一致、KEP/skew。旧 quarter 分配、`q_dual=T*q_primal` 和无空间交换差的缺陷关系不再强制。固定 mesh 的实际缺陷显式包含 `E_sp=q_dual-T*q_primal`，与几何质量转移差分别诊断；不要求严格 R=0，精度和 R 收敛仍需验收。空间 owner 沿用 H10i 后续通过的设计，不能恢复旧过约束。
