# H08a / 同源时空相积分材料通量

状态：**尚未验收，已按实际owner拆分推进**。H10o已通过显式闭合最终算子、原内部affine及H10b-dissipation-v2完整研究，见[报告](H10o_Bounded_Final_Native_Convection_Report.md)。[H08a1](H08a1_Actual_Advector_Cell_Jet_Report.md)已补齐同一实际B的局部jet与分支范围；[H08a2](H08a2_Piecewise_Characteristic_Source_Report.md)失败候选保持退役，[H08a2r1](H08a2r1_Partition_Consistent_Characteristic_Report.md)已通过同一轨迹/J、原24时间族及9项回归。[H08a3](H08a3_Resolved_FirstJet_Motion_Bridge_Report.md)真实DOF先决审计FAIL，未接桥；[H08a2r2](H08a2r2_Skeleton_Motion_Selection_Report.md)原单侧选支精度先决也FAIL，生产未改；[H08a2r3](H08a2r3_Common_Regular_Advector_Report.md)已通过一份兼容native面均值的C1高阶速度可行性，原型结构和空间/时间检查完整通过，生产尚未更换。[H08a2r4](H08a2r4_Regular_Advector_Preparation_Report.md)已通过生产准备层，144结构组和12+6 source布局、9/9回归保持。[H08a2r5](H08a2r5_Material_Reference_Polynomial_Degree_Report.md)已关闭两份材料/dual参考的次数限制，原1154行与5/5回归保持，生产未改。[H08a2r6](H08a2r6_Benchmark_Polynomial_Schema_Report.md)已关闭三处benchmark系数列假设，原34表/716228行保持（计时单列），生产未改。[H08a2r7](H08a2r7_Complete_Normal_Polynomial_Report.md)已通过完整五项表示/相率转换及两份参考，9/9回归与原输出保持。[H08a2r8](H08a2r8_Regular_Advector_Evaluation_Report.md)共同解析值/J/完整atom已通过144结构组及9/9回归，实际来源尚未切换。[H08a2r9](H08a2r9_Spatial_Source_Consumer_Contracts_Report.md)精度前置FAIL：原64布局的6个适用窄域丢失解析精度，原测试与生产保持。[H08a2r10](H08a2r10_Identifiable_Lower_Space_Preparation_Report.md)已PASS：关闭六反例，原56/56适用布局、448低阶输入、144结构组及9/9回归保持。[H08a2r9恢复](H08a2r9_Spatial_Source_Consumer_Contracts_Resume_Report.md)已PASS：原覆盖和双来源独立物理契约通过，production 0。[H08a2r11](H08a2r11_Common_Regular_Source_Deployment_Report.md)部署审计**FAIL**、候选退役；[H08a2r12](H08a2r12_Regular_Source_Arithmetic_Consumer_Report.md)**PASS（浮点消费者）**：完整chart单位一致预算、严格实际分片事件及数值J检查，48布局/1152输入与隔离候选phase/characteristic通过，production 0。[H08a2r13](H08a2r13_Benchmark_Source_Observer_Report.md)**PASS（研究观察器）**：旧patch导出已退役，原37表/733364行、五点完整次数参考和9/9回归通过，production 0。[r11恢复](H08a2r11_Common_Regular_Source_Deployment_Resume_Report.md)**FAIL**：原4窄域affine及常数场精度缺陷、闭域旧零功消费者与非线性J参考尚未闭合；候选退役，原源码恢复。[r14](H08a2r14_Identifiable_Constant_Subspace_Report.md)**PASS（准备层）**：原4 dual affine/常数反例关闭，64布局536输入、144结构组和9/9回归通过，仅216条低阶缺秩权重改变；当前实际来源仍旧。[r15](H08a2r15_Closed_Material_Energy_Reference_Report.md)**PASS（消费者）**：原四closed非零功验真实q/R/uR身份，124场景/6144 DOF、三负控与9/9回归通过，production 0。[r16](H08a2r16_Resolved_Nonlinear_Motion_Reference_Report.md)**FAIL（候选J精度）**：真实分片参考预算≤3.11e−14，原2560步两J误差2.334e−10/2.533e−9超1e−11；原覆盖及9/9回归保持，production/test 0。[r17](H08a2r17_Nonlinear_Crossing_Jacobian_Accuracy_Report.md)**PASS（隔离算法）**：分片Picard点/J同源，原两2560步J加预算7.364e−13/2.592e−13通过；原全覆盖、point-only负控及9/9回归保持，尚未部署。下一唯一任务恢复[r11](H08a2r11_Common_Regular_Source_Deployment_TODO.md)同步部署并重验原完整H10b-v2；H11未启动。目前F仍是空间瞬时率加中点时间近似，R/E_sp/G保留；本父任务没有因局部jet通过而完成。任意sharp-cut精确affine与动态准备效率未获普遍保证，不能修复质量来满足算子。H11未启动。

目标：保持Pure FirstJet/Hermite–GALS几何完全独立，在Hydro侧从同一实际步内几何和特征运动积分共享face的液/气相输运，构造唯一材料通量F_rho，使材料连续性缺陷R成为可收敛的小离散余项。

允许修改：启动时先审计H07/H08/H09的来源、完整clock及共享子面API，再按真实owner职责拆分并固定每项不超过5 production / 2 test的预算。2026-10-05审计发现实际B缺少局部分支导数，且切向跳跃不满足原Core连续迹契约；不能直接用任意速度callback或三个snapshot接线。首个实现子任务[H08a1](H08a1_Actual_Advector_Cell_Jet_TODO.md)限2 production/1 test，补齐同一B的局部jet与分支范围；随后定义跨分支运动/来源，再接时空相积分、primal/dual同一材料积分。完整门槛仍归本父任务，不由子任务局部通过替代。

禁止修改：Interface primary、几何发布/曲率、库存、bubble、逐cell体积拟合、材料修复或另一套rho*u通量。不以积分通量更新一个守恒质量状态；真实材料质量仍直接来自唯一GALS几何。

数学约束：液气相积分共享同一时空几何，材料积分为rho_l*Q_l+rho_g*Q_g；内部共享face和2:1真实subfaces保持唯一来源与代数抵消。逐cell和dual的R必须从真实几何质量变化及该唯一积分重新核算，不能设为0。继续现有uR、|u|²R/2及KEP相容对流，不反向约束界面。

实现要求：先定义同源步内几何/characteristic来源、积分精度预算、时间层和拒绝条件。仅三个独立snapshot做插值或midpoint面积乘dt不能自动称为同源时空相积分；不得重新启用历史守恒Interface driver作为生产owner。

验收：启动前在实现前设计中固定T0/T1/T2数值门槛及完整研究窗口。至少包括真实moving/crossing相面、XY/RZ uniform/2:1、共享face求和、光滑与穿越情况下R的空间/时间收敛、密度比1/1e3/1e6、既有常速度/uR/KE预算、真实regrid来源重建及全部前置回归。不得以严格R=0为目标，不能在结果出来后改阈值。

失败规则：不同源、第二材料通量、不可收敛或来源拒绝失败判FAIL；无旧midpoint或守恒库存fallback。真正外部依赖阻断才BLOCKED。

交付：唯一积分API/实现、R及材料功的独立完整证据、明确误差和剩余缺陷。H08历史报告保持原裁决，不把旧中点研究改标为时空积分。

## H08/H09 解除过约束（2026-10-04 用户授权）

材料耦合硬约束仅四项：唯一共享材料通量、内部面反号共享/AMR 子面守恒、来源一致、KEP/skew。旧 quarter 分配、`q_dual=T*q_primal` 和无空间交换差的缺陷关系不再强制。固定 mesh 的实际缺陷显式包含 `E_sp=q_dual-T*q_primal`，与几何质量转移差分别诊断；不要求严格 R=0，精度和 R 收敛仍需验收。空间 owner 沿用 H10i 后续通过的设计，不能恢复旧过约束。
